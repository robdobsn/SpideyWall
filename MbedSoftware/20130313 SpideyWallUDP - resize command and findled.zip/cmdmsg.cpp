#include "mbed.h"
#include "cmdmsg.h"
#include "ledstrip.h"
#include "detectled.h"


/*

Message format is:
    <CMD><CMD><CMD> ... <ZERO>
    
Where:
    <ZERO> is a single byte with value 0
    <CMD> is a series of bytes as follows:
        <LEN><COD><PARAMS>
        
Where:
    <LEN> is a single byte with value 1..255 depicting msg len
    <COD> is a command code - see below
    <PARAMS> are a series of bytes containing the parameters for the command
    
<COD> values:
    0x01:
        Clear the entire strip
    0x02:
        Fill a series of leds with RGB values
        <PARAMS> := <START><NUM><RGB1><RGB2>
        Where:
            <START> is a two byte value (bigendian) for led to start series
            <NUM> is a two byte (bigendian) number of leds to set
            <RGB1> is the starting RGB value (24bits)
            <RGB2> is the ending RGB value (24bits) - OPTIONAL
        The RGB2 value is optional - the LEN value determines whether it is present or not
        - if present the colour values are interpolated (HSV) between RGB1 and RGB2
        - if not present all leds are set to colour RGB1
    0x03:
        Detect LED with opto-sensor (put opto-sensor on LED and run command)
        Sensor must be attached to p20 - currently using BPX65 with 470K pullup
        Returns string with LED number
    0x04:
        Set number of leds and split point
        <PARAMS> := <NUMLEDS><SPLITPOINT>
        Where:
            <NUMLEDS> is a two byte (bigendian) value for number of leds in strip
            <SPLITPOINT> is a two byte (bigendian) value for point at which DigitalOut(p10) is used instead of p12 for data
                    (this is because the spidey wall is two parallel chains of LEDS)
*/

char* cmdmsg::Interpret(ledstrip* pLedStrip)
{
    // Clear response string
    responseStr[0] = 0;
    
    // Get message details
    unsigned char* ledStrip = pLedStrip->GetBuffer();
    unsigned char* msg = mpMsgBuf;
    int nBytesLeft = mMsgLen;
    while (nBytesLeft > 0)
    {
        // Length of chunk
        int chunkLen = *msg++;
        if (chunkLen == 0)
            break;
        
        // Params length
        int paramsLen = chunkLen - 1;
 //       printf("Chunklen = %d, Paramslen = %d\n", chunkLen, paramsLen);
        
        // Command    
        int cmdCode = *msg++;
        switch(cmdCode)
        {
            case 0x01: // Clear
            {
//                printf("Clear - nextbyte %d\n", msg[0]);
                pLedStrip->Clear();
                break;
            }
            case 0x02: // Fill
            {
//                printf("Fill\n");

                if (paramsLen == 10)  // RGB2 is provided
                {
                    int startLed = (msg[0] * 256) + msg[1];
                    int numLeds = (msg[2] * 256) + msg[3];
                    pLedStrip->Fill(startLed, numLeds, msg[4], msg[5], msg[6], msg[7], msg[8], msg[9]);
                } else if (paramsLen == 7) // only RGB1 - so solid colour fill
                {
                    int startLed = (msg[0] * 256) + msg[1];
                    int numLeds = (msg[2] * 256) + msg[3];
                    pLedStrip->Fill(startLed, numLeds, msg[4], msg[5], msg[6]);
                }
                break;
            }
            case 0x03: // Detect LED
            {
                detectled ledDetector(p20);
                int selectedLed = ledDetector.DetectSelectedLed(pLedStrip);
                sprintf(responseStr, "OK LED %d", selectedLed);
                break;
            }
            case 0x04: // Set numleds and splitpoint
            {
//                printf("Set numleds and splitpoint\n");

                if (paramsLen == 4)
                {
                    int numLeds = (msg[0] * 256) + msg[1];
                    int splitPoint = (msg[2] * 256) + msg[3];
                    pLedStrip->Resize(numLeds, splitPoint);
                }
                sprintf(responseStr, "OK Resize");
                break;
            }
            default:
            {
                sprintf(responseStr, "CMD %d UNKNOWN", cmdCode);
                break;
            }
        }
        
        // Move to next chunk
        nBytesLeft = nBytesLeft - chunkLen - 1;
        msg += paramsLen;
//        printf("Bytesleft = %d, msg[0] = %d\n", nBytesLeft, msg[0]);
   }
   return responseStr;
}
