
class ledstrip;

class cmdmsg
{
    private:
        char responseStr[30];
        unsigned char* mpMsgBuf;
        int mMaxMsgLen;
        int mMsgLen;
        
    public:
        cmdmsg()
        {
            mMsgLen = 0;
            mMaxMsgLen = 500;
            mpMsgBuf = new unsigned char [mMaxMsgLen]();
            responseStr[0] = 0;
        }
        
        ~cmdmsg()
        {
            delete mpMsgBuf;
        }
        
        char* GetBuffer()
        {
            return (char*)mpMsgBuf;
        }
        int GetMaxMsgLen()
        {
            return mMaxMsgLen;
        }
        
        void SetMsgLen(int n)
        {
            mMsgLen = n;
        }
        char* Interpret(ledstrip* pLedStrip);
};

