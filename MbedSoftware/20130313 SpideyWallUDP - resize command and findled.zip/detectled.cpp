#include "detectled.h"
#include "ledstrip.h"

detectled::detectled(PinName optoDetectorPin) :
        optoAnalogIn(*new AnalogIn(optoDetectorPin))
{
}

void detectled::FillLedsWithBinaryPattern(int val, int evensOn, ledstrip* pLedStrip)
{
    int ctr = 0;
    int bitOn = 0;
    for (int i = 0; i < pLedStrip->GetNumLeds(); i++)
    {
        if (ctr >= val)
        {
            bitOn = !bitOn;
            ctr = 0;
        }
        if (bitOn ^ evensOn)
            pLedStrip->Fill(i,1,0,0,0);
        else
            pLedStrip->Fill(i,1,0x30,0x30,0x30);
        ctr++;
    }
}

int detectled::ReadLev()
{
    int newVal1 = optoAnalogIn.read_u16();
    int newVal2 = optoAnalogIn.read_u16();
    int newVal3 = optoAnalogIn.read_u16();
    if (newVal1 < newVal2)
    {
        int tmpVal = newVal1;
        newVal1 = newVal2;
        newVal2 = tmpVal;
    }
    if (newVal2 < newVal3)
    {
        int tmpVal = newVal2;
        newVal2 = newVal3;
        newVal3 = tmpVal;
    }
    if (newVal1 < newVal2)
    {
        int tmpVal = newVal1;
        newVal1 = newVal2;
        newVal2 = tmpVal;
    }
    return newVal2;
}

int detectled::DetectSelectedLed(ledstrip* pLedStrip)
{
    // Find which LED is lit
    int startVal = 1;
    int dataVal = 0;
    int bitMask = 1;
    
    pLedStrip->Clear();
    while (startVal < pLedStrip->GetNumLeds())
    {
        FillLedsWithBinaryPattern(startVal, false, pLedStrip);
        pLedStrip->ShowLeds();
        wait_ms(20);  
        int lev1 = ReadLev();
        FillLedsWithBinaryPattern(startVal, true, pLedStrip);
        pLedStrip->ShowLeds();
        wait_ms(20);  
        int lev2 = ReadLev();
        dataVal |= (lev1 > lev2) ? (0xffffff & bitMask) : 0;
        bitMask = bitMask << 1;
        startVal = startVal * 2;
        //pc.printf("Data = %02x %d %b\n", dataVal, dataVal, dataVal);
    }
    pLedStrip->Clear();
    
    printf ("LED = %d\n", dataVal);
    
    return dataVal;
    
 }