#include "mbed.h"

class ledstrip;

class detectled
{
    private:
        void FillLedsWithBinaryPattern(int val, int evensOn, ledstrip* pLedStrip);
        int ReadLev();
        AnalogIn& optoAnalogIn;
        
    public:
        detectled(PinName optoDetectorPin);
        int DetectSelectedLed(ledstrip* pLedStrip);      

};