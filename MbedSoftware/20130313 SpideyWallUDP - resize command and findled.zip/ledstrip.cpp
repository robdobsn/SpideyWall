#include "ledstrip.h"
#include "colourconverters.h"
#include "stddef.h"

ledstrip::ledstrip(int length, int splitPoint, PinName clkPin, PinName data1Pin, PinName data2Pin) :
        clk(*new DigitalOut(clkPin)), dat1(*new DigitalOut(data1Pin)), dat2(*new DigitalOut(data2Pin))
{
    leds = 0;
    Resize(length, splitPoint);
}

ledstrip::~ledstrip()
{
    delete leds;
}

void ledstrip::Resize(int length, int splitPoint)
{
    if (leds != 0)
        delete leds;
    leds = new unsigned char[length*mColoursPerLed];
    mLedsInStrip = length;
    mSplitPoint = splitPoint;
    mMaxChainLength = mSplitPoint;
    if (mMaxChainLength < length - splitPoint)
        mMaxChainLength = length - splitPoint;
}

void ledstrip::Clear()
{
/*    Timer timr;
    timr.start();
    for (int i = 0; i < mLedsInStrip*mColoursPerLed; i++)
        leds[i] = 0;
    timr.stop();
    printf("ClearTime loop %d\n", timr.read_us());  // Result is 863uS for 2500 x 3colour LEDS
    timr.reset();
    timr.start();
 */
    memset(leds, 0, mLedsInStrip*mColoursPerLed);
 /*   timr.stop();
    printf("ClearTime memset %d\n", timr.read_us());  // Result is 35uS for 2500 x 3 colour LEDS
*/
}

unsigned char* ledstrip::GetBuffer()
{
    return leds;
}

int ledstrip::GetBufferSizeinBytes()
{
    return mLedsInStrip*mColoursPerLed;
}

// Fill - solid colour
void ledstrip::Fill(int startLed, int numLeds, 
                int r1, int g1, int b1)
{
/*    Timer timr;
    timr.start();
*/
    if ((startLed < 0) || (startLed >= mLedsInStrip))
        return;
    if (numLeds >= mLedsInStrip - startLed)
        numLeds = mLedsInStrip - startLed;
    int pos = startLed * mColoursPerLed;
    for (int i = 0; i < numLeds; i++)
    {
        leds[pos] = (unsigned char) r1;
        leds[pos+1] = (unsigned char) g1;
        leds[pos+2] = (unsigned char) b1;
        pos += mColoursPerLed;
    }
/*    timr.stop();
    printf("Fill solid %d\n", timr.read_us()); // Fill 50 LEDS solid colour = 11uS
    */
}

// Fill - with interpolation of colours using HSV colour space
void ledstrip::Fill(int startLed, int numLeds, 
                int r1, int g1, int b1, 
                int r2, int g2, int b2)
{
/*    Timer timr;
    timr.start();
    */
    if ((startLed < 0) || (startLed >= mLedsInStrip))
        return;
    if (numLeds >= mLedsInStrip - startLed)
        numLeds = mLedsInStrip - startLed;
    int pos = startLed * mColoursPerLed;
    RgbColor startRGB(r1,g1,b1);
    HsvColor startHsv = RgbToHsv(startRGB);
    RgbColor endRGB(r2,g2,b2);
    HsvColor endHsv = RgbToHsv(endRGB);
    int curH = startHsv.h << 16;
    int curS = startHsv.s << 16;
    int curV = startHsv.v << 16;
    int interpSteps = numLeds - 1;
    if (interpSteps < 1)
        interpSteps = 1;
    int incH = ((endHsv.h - startHsv.h) << 16) / interpSteps;
    int incS = ((endHsv.s - startHsv.s) << 16) / interpSteps;
    int incV = ((endHsv.v - startHsv.v) << 16) / interpSteps;
    // Since H is a polar value we need to find out if it is best to go clockwise or anti-clockwise
    if (endHsv.h > startHsv.h)
    {
        if (endHsv.h-startHsv.h > 128)
            incH = ((startHsv.h-endHsv.h) << 16) / interpSteps;
    }
    else
    {
        // Go "round the top" using modulo result
        if (startHsv.h-endHsv.h > 128)
            incH = ((endHsv.h + 255 - startHsv.h) << 16) / interpSteps;
    }
    
//    printf("StartHSV %d %d %d EndHSV %d %d %d IncHSV %d %d %d\n", startHsv.h, startHsv.s, startHsv.v, endHsv.h, endHsv.s, endHsv.v, incH, incS, incV);
    for (int i = 0; i < numLeds; i++)
    {
        RgbColor colrVal = HsvToRgb(HsvColor((curH>>16)&0xff,curS>>16,curV>>16));
        leds[pos] = colrVal.r;
        leds[pos+1] = colrVal.g;
        leds[pos+2] = colrVal.b;
//        printf("HSV %d %d %d RGB %d %d %d\n", curH>>16, curS>>16, curV>>16, colrVal.r, colrVal.g, colrVal.b);
        pos += mColoursPerLed;
        curH = curH + incH;
        curS = curS + incS;
        curV = curV + incV;
    }
    /*
    timr.stop();
    printf("Fill gradient %d\n", timr.read_us());  // Fill gradient 50 LEDS = 64uS
    */
}

    
void ledstrip::ShowLeds()
{
    for (int j = 0; j < mMaxChainLength; j++)
    {
        int pos1 = (j - mMaxChainLength + mSplitPoint) * mColoursPerLed;
        int pos2 = (j + mLedsInStrip - mSplitPoint) * mColoursPerLed;
        for (int k = 0; k < mColoursPerLed; k++)
        {
            unsigned char tval1 = 0;
            if (pos1 >= 0)
                tval1 = leds[pos1+k];
            unsigned char tval2 = 0;
            if (pos2 >= 0)
                tval2 = leds[pos2+k];
            for (int i = 0; i < 8; i++)
            {
                dat1 = (tval1 & 0x80) != 0;
                tval1 = tval1 << 1;
                dat2 = (tval2 & 0x80) != 0;
                tval2 = tval2 << 1;
                clk = 1;
                clk = 0;
                wait_us(1);
            }
        }
    }
    wait_us(750);
}    

