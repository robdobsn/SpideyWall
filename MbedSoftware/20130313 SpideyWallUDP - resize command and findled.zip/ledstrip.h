#include "mbed.h"

class ledstrip
{
    private:
        unsigned char* leds;
        int mLedsInStrip;
        int mSplitPoint;
        int mMaxChainLength;
        DigitalOut& clk;
        DigitalOut& dat1;
        DigitalOut& dat2;
        
    public:
        static const int mColoursPerLed = 3;

    public:
        ledstrip(int length, int splitPoint, PinName clkPin, PinName data1Pin, PinName data2Pin);
        ~ledstrip();
        unsigned char* GetBuffer();
        int GetBufferSizeinBytes();
        void Resize(int length, int splitPoint);
        int GetNumLeds()
        {
            return mLedsInStrip;
        }
        void Clear();
        void Fill(int startLed, int numLeds, 
                int r1, int g1, int b1, 
                int r2, int g2, int b2);
        void Fill(int startLed, int numLeds, 
                int r1, int g1, int b1);
        void ShowLeds();
        
};
