#include "mbed.h"
#include "EthernetInterface.h"
#include "ledstrip.h"
#include "cmdmsg.h"

AnalogIn ain(p20);
Serial pc(USBTX, USBRX);

const int UDP_SERVER_PORT = 7;
const int TOTAL_NUM_LEDS = 96;
const int SPLIT_POINT = 64;

int main (void)
{
    ledstrip* pLedStrip = new ledstrip(TOTAL_NUM_LEDS, SPLIT_POINT, p11, p12, p10);
    cmdmsg* pCmdMsg = new cmdmsg();

    pLedStrip->Clear();
    pLedStrip->ShowLeds();

    EthernetInterface eth;
    eth.init(); //Use DHCP
    eth.connect();
    printf("IP Address is %s\n", eth.getIPAddress());
    
    UDPSocket server;
    server.bind(UDP_SERVER_PORT);    
    Endpoint client;
        
    while (true)
    {
        char* responseStr = "";
        int n = server.receiveFrom(client, pCmdMsg->GetBuffer(), pCmdMsg->GetMaxMsgLen());
        if (n > 0)
        {
            pCmdMsg->SetMsgLen(n);
            responseStr = pCmdMsg->Interpret(pLedStrip);
            pLedStrip->ShowLeds();
        }
        // Send response back
        if (strlen(responseStr) != 0)
            server.sendTo(client, responseStr, strlen(responseStr));
    }
}
