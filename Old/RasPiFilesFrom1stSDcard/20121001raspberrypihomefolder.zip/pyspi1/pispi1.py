import spi
from time import sleep

a = spi.SPI(0,0)
print "PY: initisalising SPI mode ...\n"

