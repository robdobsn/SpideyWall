vncserver :1 -geometry 1920x1080 -depth 24
